from django.contrib import admin

from .models import Form




admin.site.register(Form)
# Register your models here.
