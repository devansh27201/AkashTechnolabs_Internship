from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User, auth

from .models import Form



def homepageview(request):
    return render(request,'home.html')


def aboutusview(request):
    return render(request,'about.html')


def contactusview(request):
    return render(request,'contact.html')

def form(request):
    return render(request, 'form.html')

def process(request):
    print('Welcome')
    print(request.method)
    print(request.POST)
    first = request.POST.get('name', '')
    last = request.POST.get('name1', '') 
    userId = request.POST.get('username', '')
    username = request.POST.get('email', '')
    pwd = request.POST.get('pass1', '')
    spwd = request.POST.get('pass2', '')
    mno = request.POST.get('mobile', '')   
    date = request.POST.get('date', '')
    course = request.POST.get('selection', '')
    college = request.POST.get('college', '')
    add = request.POST.get('address', '')
    check= bool(request.POST.get('check'))
    select = request.POST.get('select', 'default value')
    user = Form(email=username, password=pwd, firstname=first, lastname=last, 
                                username=userId, col_name=college, address=add, mobile=mno, course=course, gender=select)
    user.save()
    print('User created')
    return redirect('/')



    return render(request, 'details.html',{'flm':first,'last':last, 'usm':username,
                    'pwd':pwd,'spwd':spwd,'mobile':mno,'date':date, 'c':course, 'clg':college, 'a':add,'ch':check,'s':select, 'u':user})

# Create your views here.
