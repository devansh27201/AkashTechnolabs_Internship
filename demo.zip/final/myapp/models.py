from django.db import models

class Form(models.Model):
  firstname = models.CharField(max_length=122)
  lastname = models.CharField(max_length=122)
  email = models.EmailField(max_length=120)
  username = models.CharField(max_length=60 ,unique=True,default = '')
  password = models.TextField()
  date = models.DateTimeField(auto_now_add=True)
  col_name = models.CharField(max_length=50, default='')
  address = models.TextField()
  mobile = models.CharField(max_length=10)
  course = models.CharField(max_length=20)
  gender = models.CharField(max_length=10)
  
# Create your models here.
