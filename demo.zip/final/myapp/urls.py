from django.urls import path
from . import views

urlpatterns = [
    path('',views.homepageview,name = 'home.html'),
    path('about',views.aboutusview,name = 'about.html'),
    path('contact',views.contactusview,name = 'contact.html'),
    path('form',views.form,name = 'form.html'),
    path('formprocess',views.process,name = 'process'),
    
]